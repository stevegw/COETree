// $scope, $element, $attrs, $injector, $sce, $timeout, $http, $ionicPopup, and $ionicPopover services are available

// **********************************************************************************************
// Developed by Steve Grey-Wilson 19/9/2022
// **********************************************************************************************


// **********************************************************************************************
// This is a useful command that provides links in the console log to the application document object model and javascript
console.log($scope.app);
// **********************************************************************************************
// **********************************************************************************************



// Globals

LOG_MESSAGE_FAILURE = 'A failure occured';
LOG_MESSAGE_CONNECTION_FAILURE = 'This action initially tries to connect to Windchill if its failing, check the windchill server is up and running';

LOG_MESSAGE_SERVICE_FAILED = "which is unexpected. You could try again and if that fails, try a different Part. If that fails please connect with support to help understand the problem";
LOG_MESSAGE_GETPARTS_FAILED = "which is unexpected. Please check server is running, console log and maybe permissions";

// **********************************************************************************************
// Local Functions
// The function that do not have the $scope prefix and created as helper functions
// These functions can not be used in the studio widget js.
// **********************************************************************************************
// **********************************************************************************************





populateInfoPopup = function (message, issue , action)   {

  DoText (message + " ... " + issue + " ... " + action ); 

}




var popover ;

doDynamicPopup = function (value , occurence , model )  {
  
  try {
    
    var template   = '<ion-popover-view><ion-content>&nbsp;' + occurence +  '&nbsp;</br>&nbsp;' + value +  '<br>'+ " Getting Latest Info! " + '&nbsp;</ion-content></ion-popover-view>';
    popover = $ionicPopover.fromTemplate(template, {
      scope: $scope
   	});
   	var customEvent = {
        	target: {
          		getBoundingClientRect:function () {
            		return {
              			'left'  :$scope.lastClick.x,
              			'top'   :$scope.lastClick.y,
              			'width' :1,
              			'height':1
           		 	};
          		}
        	}
   	};
    
    // show the popover at the position the user clicked
    //
   
    hilite([model+"-"+occurence], true); 
    popover.show(customEvent);
    $scope.metaDataCategory(model, $scope.app.params.CURRENT_PATHID);
    
   	// auto-close the popover after 1 seconds
    $timeout(function() {
                popover.remove();
                hilite([model+"-"+$scope.app.params.CURRENT_PATHID], false); 
                
	}, 3000); 

  } catch (err) {
    console.log('>>>doDynamicPopup<<< Unable to display popup an error occurred >>> ' + err + "<<<");
  }
  
}



positionModelXYZ = function (modelname , offset , serviceName) {
  
	let boundingBoxX1 = $scope.app.mdl['WCHelper'].svc[serviceName].data.current['boundingBoxX1'];
	let boundingBoxY1 = $scope.app.mdl['WCHelper'].svc[serviceName].data.current['boundingBoxY1'];
	let boundingBoxZ1 = $scope.app.mdl['WCHelper'].svc[serviceName].data.current['boundingBoxZ1'];
	let boundingBoxX2 = $scope.app.mdl['WCHelper'].svc[serviceName].data.current['boundingBoxX2'];
	let boundingBoxY2 = $scope.app.mdl['WCHelper'].svc[serviceName].data.current['boundingBoxY2'];
	let boundingBoxZ2 = $scope.app.mdl['WCHelper'].svc[serviceName].data.current['boundingBoxZ2'];

    $scope.view.wdg[modelname].visible=true;
    $scope.view.wdg["modelMain"].opacity = 1.0;
    $scope.view.wdg["modelMain"].scale = 1.0;
  
      try {
        
        
         $scope.view.wdg["modelBoundary1"].y=boundingBoxX1;
         $scope.view.wdg["modelBoundary1"].z=boundingBoxY1;
         $scope.view.wdg["modelBoundary1"].x=boundingBoxZ1;
        
         $scope.view.wdg["modelBoundary2"].y=boundingBoxX2;
         $scope.view.wdg["modelBoundary2"].z=boundingBoxY2;
         $scope.view.wdg["modelBoundary2"].x=boundingBoxZ2;


         var loadedModelPosX = -1.0*( boundingBoxX1 + boundingBoxX2) / 2.0;
         var loadedModelPosZ = -1.0*( boundingBoxZ1 + boundingBoxZ2) / 2.0;
         var loadedModelPosY = -1.0*(boundingBoxY1);

         $scope.view.wdg[modelname].y=loadedModelPosY;
         $scope.view.wdg[modelname].z=loadedModelPosZ;
         $scope.view.wdg[modelname].x=loadedModelPosX;
        
         if (offset == true && $scope.view.wdg.checkBoxOverlay.value == false) {

             let move = (Math.abs(boundingBoxX1) + Math.abs(boundingBoxX2) + (Math.abs(boundingBoxX1) + Math.abs(boundingBoxX2))*0.1  );
             $scope.view.wdg[modelname].x=loadedModelPosX + move  ;

          } else if (modelname == "modelWVS"  && $scope.view.wdg.checkBoxOverlay.value == true ) {
            
            
            try {
            
             $scope.view.wdg[modelname].y=$scope.view.wdg["modelMain"].y;
             $scope.view.wdg[modelname].z=$scope.view.wdg["modelMain"].z;
             $scope.view.wdg[modelname].x=$scope.view.wdg["modelMain"].x;
             $scope.view.wdg["modelMain"].opacity = 0.2;
              
            } catch(ex) {
              console.log(">>>positionModelXYZ<<< Whilst setting widget values an error occured=" + ex);
            }

          }

      } catch (ex) {
         console.log(">>>positionModelXYZ<<< had an error=" + ex);
      }
  
     $scope.view.wdg[modelname].visible=true;
  
}


//
// highlighting function. Inputs are the selected part and a boolean for hilite

hilite = function (items, hilite) {
  items.forEach(function(item) {
    //
    //set the properties of the TML 3D Renderer to highlight the selected item using a TML Text shader. "green" is the name of the script for the TML Text.
    tml3dRenderer.setProperties(item, hilite === true ? { shader: "green", hidden: false, opacity: 0.5, phantom: false, decal: true }
                                                      : { shader: "Default", hidden: false, opacity: 1.0, phantom: false, decal: false });
  }) 

} 


setColor = function (items, color) {
  items.forEach(function (item) {
    tml3dRenderer.setColor(item, color);
  });
}


// **********************************************************************************************
// Listerner Functions
// **********************************************************************************************
// ****************

//
// keep a note of the last location the user tapped on the screen - we use this to 
// position the popup label
//
document.addEventListener('click', function (event) {
  $scope.lastClick = {
    x: event.pageX, y: event.pageY
  };
});

// **********************************************************************************************


// **********************************************************************************************
// Events Functions
// **********************************************************************************************
// ****************

/*$scope.$on('userpick', function(event, targetName, targetType, eventData) {
  
  try {
      var pathid = JSON.parse(eventData).occurrence;
      $scope.app.params.CURRENT_PATHID = pathid;

      PTC.Metadata.fromId(targetName).then((metadata) => {
        var displayName = metadata.get(pathid, 'Display Name');
        doDynamicPopup(displayName, pathid , targetName );

     });
    
  } catch (err) {
     console.log("Event $on had error="+ err);
    
  }

});*/

// **********************************************************************************************

// **********************************************************************************************
// Events
// **********************************************************************************************
// ****************




$scope.$on("saveJsonMetaData.serviceInvokeComplete", function(evt, arg)
  {

    $scope.postQuickMessage('Getting Extended Metadata');

    var TWXmodelID = 'WCHelper';
    var serviceName = 'GetExtendedMetadata';
    var parameters = { "fileGUID" : $scope.app.params.PVZGUID  , "partIDUsed" : '' , "returnMetadataJSON" : false }; 
  
    $timeout(function() {
      
      // add a small delay to make sure properties are set
      twx.app.fn.triggerDataService(TWXmodelID, serviceName, parameters);
    
    },1000);

  }
          
);


$scope.$on("GetExtendedMetadata.serviceInvokeComplete", function(evt, arg)
  {
  
      positionModelXYZ("modelMain",false , "GetExtendedMetadata");
      $scope.app.params.CURRENT_WVS_URL = $scope.view.wdg.modelMain.src ; 
  
      $scope.postQuickMessage('Loading Model');
      $scope.HidePopup("popupMessage"); 
  }
          
);



$scope.$on("GetStructureWithLevels.serviceInvokeComplete", function(evt, arg)
  {
  
      $scope.postQuickMessage('Structure retrieved');

  }
          
);



// *****************************************************************************************************************
// If a service fails 
// *****************************************************************************************************************


$scope.$on("UploadPVZfromDynamic.serviceFailure", function(evt, arg)
  {
     $scope.doPopupMessage(true, "The generation of the PVZ failed," + LOG_MESSAGE_SERVICE_FAILED  + "  system message "+ arg.message);
  }       
          
)

$scope.$on("saveJsonMetaData.serviceFailure", function(evt, arg)
  { 
     $scope.doPopupMessage(true, "The saving of the extended JSON failed," + LOG_MESSAGE_SERVICE_FAILED  + "  system message "+ arg.message);
  }       
          
)

$scope.$on("GetExtendedMetadata.serviceFailure", function(evt, arg)
  {
     $scope.doPopupMessage(true, "Getting extended Metadata failed," + LOG_MESSAGE_SERVICE_FAILED  + "  system message "+ arg.message );
  }       
          
)

$scope.$on("GetStructureWithLevels.serviceFailure", function(evt, arg)
  {
     $scope.doPopupMessage(true, "Getting Structure failed," + LOG_MESSAGE_SERVICE_FAILED  + "  system message "+ arg.message );
  }       
          
)

$scope.$on("GetPartsByContextAndNameFilter.serviceFailure", function(evt, arg)
  {
     $scope.doPopupMessage(true, "Getting Parts failed," + LOG_MESSAGE_GETPARTS_FAILED + "  system message "+ arg.message);
  }       
          
)



// **********************************************************************************************

// **********************************************************************************************
// Studio Functions
// **********************************************************************************************
// ****************


$scope.doPopupMessage = function ( show, message) {
  
  try {

    $scope.app.params.CURRENT_MESSAGE = message;
    $scope.view.wdg.popupMessage.visible = show;

  } catch (err) {
    console.log('>>>doPopupMessage<<< Unable to display Message popup an error occurred >>> ' + err + "<<<");
  }

}


$scope.postQuickMessage = function (message) {
  
  twx.app.fn.addSnackbarMessage(message);
  
}


$scope.logMessage = function (currentAction, currentInfoMessage) {
  
  $scope.app.params.CURRENT_ACTION = currentAction;
  switch (currentInfoMessage) {
        case "LOG_MESSAGE_CONNECTION_FAILURE":
          fail = LOG_MESSAGE_CONNECTION_FAILURE;
          break;
        case "XXX":
          fail = "Global Message name";
          break;
        default:
          fail = LOG_MESSAGE_FAILURE;
	}

    $scope.app.params.CURRENT_INFO_MESSAGE = fail;
}

$scope.SetMessage = function (message) {
  
  $scope.app.params.MESSAGE = message;
  
}

$scope.HidePopup = function (popupID) {
  
  try {
      $scope.view.wdg[popupID].visible = false;
  } catch (ex) {
    console.log(">>>HidePopup<<< failed error="+ex);
    
  }
}



$scope.getParts = function () {
  $scope.postQuickMessage("Working on getting Parts");
  
  
}


$scope.StartModelRetrieval = function () {
  
 let message =  "Getting Latest Model" ;
 if ( $scope.app.params.CURRENT_PART_NAME != undefined && $scope.app.params.CURRENT_PART_NAME != "") {
   
   message = message + " for "+ $scope.app.params.CURRENT_PART_NAME;
 }
 $scope.doPopupMessage(true, message);

}



$scope.metaDataCategory = function(model, occurance) {

  try {
    
    PTC.Metadata.fromId(model).then( (metadata) => {
     var result = metadata.get(occurance).getCategory ('__PV_SystemProperties');
     var jsonString = JSON.stringify(result);

     $scope.view.wdg.textAreaMetadata.text = jsonString;
     $scope.view.wdg.popupMetadata.visible= true;
    
    
    });
    
  } catch (ex) {
    console.log(">>>function metaDataCategory <<< failed with error="+ex);
  }

}


/*
 Pattern for reference
*/

/*
$scope.$on("MyService.serviceInvokeComplete", function(evt, arg)

  {

        $timeout(function() {

         // do something i.e start another service 

          var TWXmodelID = 'External Data name';
          var serviceName = 'Name of Servce';
          var parameters = {'Aparameter':  "value"};  

          twx.app.fn.triggerDataService(TWXmodelID, serviceName, parameters);

        }, 1750); 

  }

);*/



