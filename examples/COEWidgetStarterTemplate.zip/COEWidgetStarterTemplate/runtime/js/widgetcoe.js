

class widgetcoe {


    constructor( vuforiaScope, data, width , height , topoffset , leftoffset ,  renderer , widgetid ) {

    }
}




 
