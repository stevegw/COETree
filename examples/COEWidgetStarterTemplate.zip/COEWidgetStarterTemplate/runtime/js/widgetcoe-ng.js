if (typeof module !== 'undefined' && typeof exports !== 'undefined' && module.exports === exports) {
  module.exports = 'widgetcoe-ng';
}

(function () {
  'use strict';

  var widgetcoeModule = angular.module('widgetcoe-ng', []);
  widgetcoeModule.directive('ngWidgetcoe', ['$timeout', '$interval', '$http', '$window', '$injector', ngWidgetcoe]);

  function ngWidgetcoe($timeout, $interval, $http, $window, $injector) {

    return {
      restrict: 'EA',
      scope: {
        autolaunchField: '@',
        incomingdataField : '=',
        incomingidField : '@',
        widthField : '@',
        heightField : '@',
        topoffsetField : '@',
        leftoffsetField : '@',
        selectedvalueField : '=',
        delegateField: '='
      },
      template: '<div></div>',
      link: function (scope, element, attr) {

        var lastUpdated = 'unknown';
        let widgetcoe = undefined ;

        scope.renderer = $window.cordova ? vuforia : $injector.get('threeJsTmlRenderer');
                     
        var executeWidget = function() {
          console.log('do the custom activities here');
          if (widgetcoe != undefined) {
            try {
              //widgetcoe
            }catch(ex) {
              // ignore
            }
          }
          // //widgetcoe
        };
        var start = function() {
          console.log('Starting');
          scope.$parent.fireEvent('started');
          executeWidget();
        }
        var stop = function() {
          console.log('Stopping');
          scope.$parent.fireEvent('stopped');
          if (widgetcoe != undefined) {
            //widgetcoe 
          }
        }


        scope.$watch('incomingdataField', function () {
          console.log('dataField='+ scope.incomingdataField);

          if (scope.incomingdataField != undefined && scope.incomingdataField != '') {
            
            if (scope.autolaunchField == "true") {
              start();
            }


          }

        });

        scope.$watch('selectedvalueField', function () {
          console.log('selectedvalueField='+ JSON.stringify(scope.selectedvalueField));
          if (widgetcoe != undefined) {

            //widgetcoe
          }

        });

        scope.$watch('incomingidField', function () {
          console.log('incomingidField='+ scope.incomingidField);

        });

        scope.$watch('delegateField', function (delegate) {
          if (delegate) {
            delegate.start = function () { 
              start(); 
            };
            delegate.stop = function () { 
              stop(); 
            };
          }
        });



        // Use this initially to see if your extension get deployed
        // If you don't see this message its not deployed
        // Comment out once you have it working
        scope.$watch( function() {
          console.log("widgetcoe Any watch "); 
        });
      }
    };
  }

}());
