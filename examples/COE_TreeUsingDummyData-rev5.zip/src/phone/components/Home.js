// $scope, $element, $attrs, $injector, $sce, $timeout, $http, $ionicPopup, and $ionicPopover services are available
console.log($scope.app);
let jsonData;
let jsonFile = "app/resources/Uploaded/OR-wt-part-WTPart5694150.json";
// ************************************************************************************
// Local functions
// ************************************************************************************
gotJSON = function(data){
  console.log ("gotJSON: Working on Data >>>"+ data);
  postQuickMessage("Retrieving Data from resoure File");
  jsonData= JSON.parse(data);

}
//This reads a resource file.  When the reading is done
//the process is passed off to the "gotJSON" function
doRead = function(jsonFile){
  //
  // Beware fetch as an asynchronous process
  // So when using in a flow of Javascript the fetch will start
  // and will finish at indeterminate time
  // Any code following the fetch call will start and not wait for fetch
  //
  fetch(jsonFile)
    .then(response => response.text())
    .then(data => gotJSON(data))
    .then( 
    $timeout(function() {
      // do something i.e start another service 
      $scope.view.wdg["treeCoe-2"].incomingdata =  jsonData;
      $timeout(function() {
        // do something i.e start another service 
        twx.app.fn.triggerWidgetService("treeCoe-2", 'start') // $scope.view.view["treeCoe-1"].svc.start;
      }
               , 1000)
    }
             , 1000)
  )
}
postQuickMessage = function (message) {
  twx.app.fn.addSnackbarMessage(message);
}
dummyData = function (index) {
  var data =  [{
    "Part Name":  "SubPartName "+ index, "Part Number":  "SubPartNumber 101 "+ index , "PathId":  "SubPathID " + index , "ComponentsX" : [{
    }
                                                                                                                                         ] }
              ];
  return data;
}
BuildData = function (collection)   {
  data = {
  }
  for (var n = 0; n < collection.length; n++) {
    data[n] = dummyData(collection[n]);
  }
  return data;
}
// ************************************************************************************
// Studio exposed functions
// ************************************************************************************
$scope.SetTreeData = function (json)   {
  doRead(jsonFile);
}
// This is test function
// To show how to have a different propery name (default is Part Name)  and a josn array identifier (defaults is Components)
// Running this function 

let PROPERTYNAME ;
let IDENTIFIER ;

$scope.TestUsingDifferentDataConfig  = function ()   {
  var array1 =  dummyData("1");
  var array2 =  dummyData("2");
  var array3 =  dummyData("3");
  array2[0].ComponentsX = array3;
  array1[0].ComponentsX = array2;
  
  let PROPERTYNAME = $scope.view.wdg["treeCoe-2"].propertyname;
  let IDENTIFIER = $scope.view.wdg["treeCoe-2"].jsonarrayidentifier;

  
  $scope.view.wdg["treeCoe-1"].propertyname =  "Part Name";
  $scope.view.wdg["treeCoe-1"].jsonarrayidentifier =  "ComponentsX";
  postQuickMessage("Testing: Using Different Data Config");
  $timeout(function() {

    $scope.view.wdg["treeCoe-1"].incomingdata =  array1[0];
    $timeout(function() {
      // do something i.e start another service 
      twx.app.fn.triggerWidgetService("treeCoe-2", 'start') // $scope.view.view["treeCoe-2"].svc.start;
      $scope.view.wdg["treeCoe-2"].propertyname =  PROPERTYNAME;
      $scope.view.wdg["treeCoe-2"].jsonarrayidentifier =  IDENTIFIER;
    }
             , 500)
  }
           , 500)
  console.log(JSON.stringify(array1[0]));
}


// Exploration




$scope.createTreeFromMetadata = function() {
  
  console.log("Using Model name myModel");

 PTC.Metadata.fromId('myModel').then( (metadata) => {
       var result = metadata.get('/0/6', 'Display Name')
       
       
       
       
       
     })
       .catch((err) => { console.log('Metadata extraction failed with reason : ' + err); })
       .finally( () => { console.log('Metadata done') } 
        
       );
  
}









































